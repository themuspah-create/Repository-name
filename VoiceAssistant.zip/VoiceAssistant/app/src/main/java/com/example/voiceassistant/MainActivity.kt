package com.example.voiceassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var modelStatus: TextView
    private val fields = LinkedHashMap<String, EditText>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 40, 40, 40) }

        status = TextView(this).apply { textSize = 15f }
        root.addView(status)
        modelStatus = TextView(this).apply { textSize = 15f; setPadding(0, 8, 0, 8) }
        root.addView(modelStatus)

        fun field(key: String, hint: String, def: String, secret: Boolean = false) {
            val e = EditText(this).apply {
                this.hint = hint
                setText(Prefs.get(this@MainActivity, key, def))
                if (secret) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            }
            fields[key] = e; root.addView(e)
        }
        root.addView(TextView(this).apply {
            textSize = 14f
            setPadding(0, 24, 0, 24)
            text = "أمثلة للأوامر:\n«افتح واتساب» • «اضغط على بحث» • «انزل» • «اطلع» • «ارجع» • «الرئيسية» • «الإشعارات» • «اكتب مرحبا» • «أرسل رسالة إلى 0501234567 تقول مرحبا»"
        })

        fun button(label: String, action: () -> Unit) =
            root.addView(Button(this).apply { text = label; setOnClickListener { action() } })

        button("1) منح الصلاحيات (ميكروفون / إشعارات / فوق التطبيقات)") { requestPerms() }
        button("2) فتح إعدادات إمكانية الوصول") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("3) تشغيل المساعد") { start() }
        button("4) (اختياري) إضافة ملف الذكاء الاصطناعي .litertlm") { pickModel() }
        button("5) إضافة نموذج الصوت العربي (zip)") { pickZip(78) }
        button("6) إضافة نموذج الصوت الإنجليزي (zip)") { pickZip(79) }
        button("تبديل لغة الاستماع (عربي / English)") {
            val n = if (Prefs.get(this, "stt_lang", "ar") == "ar") "en" else "ar"
            Prefs.put(this, "stt_lang", n); refresh()
        }
        button("محرك الصوت: Google (دقيق) ⇄ Vosk (دون إنترنت)") {
            val n = if (Prefs.get(this, "stt_engine", "google") == "google") "vosk" else "google"
            Prefs.put(this, "stt_engine", n); refresh()
        }
        button("لهجة العربية (سعودي / سوداني / مصري / إماراتي / أردني)") {
            val l = listOf("ar-SA", "ar-SD", "ar-EG", "ar-AE", "ar-JO")
            val cur = Prefs.get(this, "ar_locale", "ar-SA")
            Prefs.put(this, "ar_locale", l[(l.indexOf(cur) + 1) % l.size]); refresh()
        }
        button("إيقاف المساعد") { stopService(Intent(this, OverlayService::class.java)) }

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); refresh() }
    override fun onPause() { saveFields(); super.onPause() }

    private fun pickZip(req: Int) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }
        startActivityForResult(i, req)
    }

    private fun pickModel() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
        }
        startActivityForResult(i, 77)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if ((requestCode == 78 || requestCode == 79) && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val lang = if (requestCode == 78) "ar" else "en"
            modelStatus.text = "جارٍ فك ضغط نموذج الصوت... قد يستغرق دقيقة، لا تغلق التطبيق"
            Thread {
                try {
                    contentResolver.openInputStream(uri)!!.use { VoskModels.importZip(this, lang, it) }
                    runOnUiThread { refresh(); toast("تمت إضافة نموذج الصوت") }
                } catch (e: Exception) {
                    runOnUiThread { modelStatus.text = "فشل: ${e.message}" }
                }
            }.start()
            return
        }
        if (requestCode != 77 || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        var name = ""
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && c.moveToFirst()) name = c.getString(idx) ?: ""
        }
        if (!name.endsWith(".litertlm")) {
            modelStatus.text = "اختر ملفاً ينتهي بـ .litertlm (اخترت: $name)"
            return
        }
        modelStatus.text = "جارٍ نسخ النموذج... انتظر حتى يكتمل"
        Thread {
            try {
                val out = java.io.File(filesDir, "model.litertlm")
                contentResolver.openInputStream(uri)!!.use { input ->
                    out.outputStream().use { input.copyTo(it) }
                }
                Prefs.put(this, "model_path", out.absolutePath)
                Engines.release()
                runOnUiThread { refresh(); toast("تمت إضافة النموذج") }
            } catch (e: Exception) {
                runOnUiThread { modelStatus.text = "فشل النسخ: ${e.message}" }
            }
        }.start()
    }

    private fun saveFields() = fields.forEach { (k, e) -> Prefs.put(this, k, e.text.toString().trim()) }

    private fun hasMic() = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    private fun hasNotif() = Build.VERSION.SDK_INT < 33 ||
        checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    private fun hasOverlay() = Settings.canDrawOverlays(this)
    private fun hasContacts() = checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
    private fun hasSms() = checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
    private fun hasA11y() = AssistantAccessibilityService.instance != null

    private fun refresh() {
        fun m(b: Boolean) = if (b) "✅" else "❌"
        status.text = "الميكروفون ${m(hasMic())}   الإشعارات ${m(hasNotif())}\n" +
            "الظهور فوق التطبيقات ${m(hasOverlay())}   إمكانية الوصول ${m(hasA11y())}\n" +
            "جهات الاتصال ${m(hasContacts())}   إرسال الرسائل ${m(hasSms())}"
        val mp = Prefs.get(this, "model_path", "")
        val f = java.io.File(mp)
        modelStatus.text = if (mp.isNotEmpty() && f.exists())
            "الذكاء الاصطناعي ✅ (${f.length() / 1048576} MB)"
        else "الذكاء الاصطناعي ❌ غير مضاف (تعمل الأوامر الجاهزة فقط)"
        val lg = Prefs.get(this, "stt_lang", "ar")
        modelStatus.text = modelStatus.text.toString() +
            "\nنموذج الصوت العربي " + (if (VoskModels.exists(this, "ar")) "✅" else "❌") +
            "   الإنجليزي " + (if (VoskModels.exists(this, "en")) "✅" else "❌") +
            "\nلغة الاستماع الحالية: " + (if (lg == "ar") "العربية" else "English") +
            "\nمحرك الصوت: " + (if (Prefs.get(this, "stt_engine", "google") == "google") "Google (دقيق، يحتاج إنترنت)" else "Vosk (دون إنترنت)") +
            "\nاللهجة: " + Prefs.get(this, "ar_locale", "ar-SA")
    }

    private fun requestPerms() {
        val need = mutableListOf<String>()
        if (!hasMic()) need += Manifest.permission.RECORD_AUDIO
        if (!hasNotif()) need += Manifest.permission.POST_NOTIFICATIONS
        if (!hasContacts()) need += Manifest.permission.READ_CONTACTS
        if (!hasSms()) need += Manifest.permission.SEND_SMS
        if (need.isNotEmpty()) { requestPermissions(need.toTypedArray(), 1); return }
        if (!hasOverlay()) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        refresh()
    }

    private fun start() {
        saveFields()
        if (!hasMic() || !hasOverlay()) { toast("أكمل الخطوة 1 أولاً"); return }
        if (!hasA11y()) { toast("فعّل الخدمة من إعدادات إمكانية الوصول (الخطوة 2)"); return }
        ContextCompat.startForegroundService(this, Intent(this, OverlayService::class.java))
        toast("ستظهر الأيقونة العائمة. اضغط عليها للبدء/الإيقاف، ضغطة مطولة للإغلاق")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
