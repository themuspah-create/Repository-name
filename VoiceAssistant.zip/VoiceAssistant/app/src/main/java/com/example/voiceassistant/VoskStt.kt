package com.example.voiceassistant

import android.content.Context
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.util.zip.ZipInputStream

/** Offline speech models (Vosk) stored inside the app: filesDir/vosk/<lang>. */
object VoskModels {
    fun dir(ctx: Context, lang: String) = File(ctx.filesDir, "vosk/$lang")

    fun exists(ctx: Context, lang: String): Boolean {
        val d = dir(ctx, lang)
        return d.isDirectory && (File(d, "am").exists() || File(d, "conf").exists())
    }

    /** Unzips a Vosk model zip (which has one top-level folder) into dir(ctx, lang). */
    fun importZip(ctx: Context, lang: String, input: InputStream) {
        val target = dir(ctx, lang)
        val tmp = File(ctx.filesDir, "vosk/${lang}_tmp")
        tmp.deleteRecursively()
        tmp.mkdirs()
        val base = tmp.canonicalPath + File.separator
        ZipInputStream(input.buffered()).use { zin ->
            var e = zin.nextEntry
            while (e != null) {
                val name = e.name.substringAfter('/', "")
                if (name.isNotEmpty()) {
                    val out = File(tmp, name)
                    if (!out.canonicalPath.startsWith(base)) throw IOException("ملف مضغوط غير صالح")
                    if (e.isDirectory) {
                        out.mkdirs()
                    } else {
                        out.parentFile?.mkdirs()
                        out.outputStream().use { zin.copyTo(it) }
                    }
                }
                e = zin.nextEntry
            }
        }
        target.deleteRecursively()
        if (!tmp.renameTo(target)) throw IOException("تعذّر حفظ النموذج")
    }
}

class VoskStt(
    private val ctx: Context,
    private val onText: (String) -> Unit,
    private val fail: (String) -> Unit
) {
    private var model: Model? = null
    private var loadedLang: String? = null
    private var service: SpeechService? = null

    /** Heavy (seconds). Call off the main thread. */
    @Synchronized
    fun load(lang: String) {
        if (loadedLang == lang && model != null) return
        stop()
        model?.close()
        model = null
        model = Model(VoskModels.dir(ctx, lang).absolutePath)
        loadedLang = lang
    }

    /** Call on the main thread after load(). */
    fun start() {
        val m = model ?: return
        stop()
        val rec = Recognizer(m, 16000.0f)
        val s = SpeechService(rec, 16000.0f)
        s.startListening(object : RecognitionListener {
            override fun onPartialResult(hypothesis: String?) {}
            override fun onResult(hypothesis: String?) { emit(hypothesis) }
            override fun onFinalResult(hypothesis: String?) { emit(hypothesis) }
            override fun onError(exception: Exception?) { fail(exception?.message ?: "error") }
            override fun onTimeout() {}
        })
        service = s
    }

    private fun emit(h: String?) {
        val t = try { JSONObject(h ?: "").optString("text") } catch (_: Exception) { "" }
        if (t.isNotBlank()) onText(t)
    }

    fun stop() {
        try { service?.stop(); service?.shutdown() } catch (_: Exception) {}
        service = null
    }

    fun close() {
        stop()
        try { model?.close() } catch (_: Exception) {}
        model = null
        loadedLang = null
    }
}
