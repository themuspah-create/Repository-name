package com.example.voiceassistant

import android.content.Context
import com.google.ai.edge.litertlm.Backend
import com.google.ai.edge.litertlm.Engine
import com.google.ai.edge.litertlm.EngineConfig
import java.io.File

/** On-device LLM (LiteRT-LM). Used only when the rules did not understand the request. */
class LiteRtEngine(private val ctx: Context, private val modelPath: String) {

    private val system = """
You control an Android phone. Turn the user's request (Arabic or English) into exactly ONE JSON object. Output only the JSON, nothing else.
Actions: open_app (app_name, in English), click (text), scroll (direction: up or down), type_text (text), back, home, recents, notifications, send_sms (name or number, body), none.
The user may speak any Arabic dialect (Saudi, Sudanese, Egyptian...). Understand it and always use English app names.
Examples:
"open youtube" -> {"action":"open_app","app_name":"youtube"}
"ورني الصور" -> {"action":"open_app","app_name":"photos"}
"ابغى اتصل بأحد" -> {"action":"open_app","app_name":"phone"}
"شغل الكاميرا" -> {"action":"open_app","app_name":"camera"}
"what time is it" -> {"action":"open_app","app_name":"clock"}
"scroll a bit" -> {"action":"scroll","direction":"down"}
"go back" -> {"action":"back"}
"ارجع للشاشة الرئيسية" -> {"action":"home"}
"ارسل لمؤيد تقول وينك" -> {"action":"send_sms","name":"مؤيد","body":"وينك"}
"what is the weather" -> {"action":"none"}
If you are not sure, output {"action":"none"}.
""".trimIndent()

    private var engine: Engine? = null

    @Synchronized
    private fun ensure(): Engine {
        engine?.let { return it }
        val e = Engine(
            EngineConfig(
                modelPath = modelPath,
                backend = Backend.CPU(),
                cacheDir = ctx.cacheDir.path
            )
        )
        e.initialize()
        engine = e
        return e
    }

    fun interpret(text: String): String {
        val e = ensure()
        val prompt = system + "\n\nUser: \"" + text + "\" ->"
        e.createConversation().use { c ->
            return c.sendMessage(prompt).toString()
        }
    }

    @Synchronized
    fun close() {
        try { engine?.close() } catch (_: Exception) {}
        engine = null
    }
}

/** Rules first (instant). If they do not understand, ask the on-device model (if the user added one). */
object Engines {
    private val rules = LocalEngine()
    @Volatile private var llm: LiteRtEngine? = null

    fun interpret(ctx: Context, text: String): String {
        val r = rules.interpret(text)
        if (parseCommand(r)?.optString("action") != "none") return r
        val path = Prefs.get(ctx, "model_path", "")
        if (path.isEmpty() || !File(path).exists()) return r
        val e = llm ?: synchronized(this) {
            llm ?: LiteRtEngine(ctx.applicationContext, path).also { llm = it }
        }
        return e.interpret(text)
    }

    fun release() { llm?.close(); llm = null }
}
