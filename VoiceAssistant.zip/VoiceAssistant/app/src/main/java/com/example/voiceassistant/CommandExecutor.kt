package com.example.voiceassistant

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.provider.ContactsContract
import android.telephony.SmsManager
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.json.JSONObject

object CommandExecutor {

    private val SENSITIVE_ACTIONS = setOf("send_sms")
    // Clicking a button whose label matches these also needs confirmation.
    private val SENSITIVE_WORDS = listOf(
        "send", "pay", "buy", "delete", "transfer", "confirm", "purchase", "remove",
        "إرسال", "ارسال", "دفع", "شراء", "حذف", "تحويل", "تأكيد", "إزالة"
    )
    private val ALLOWED = setOf(
        "open_app", "click", "scroll", "type_text", "back", "home", "recents", "notifications", "send_sms"
    )

    fun isAllowed(cmd: JSONObject) = cmd.optString("action") in ALLOWED

    /** Decided here in code, never by the model. */
    fun isSensitive(cmd: JSONObject): Boolean {
        val action = cmd.optString("action")
        if (action in SENSITIVE_ACTIONS) return true
        if (action == "click") {
            val t = cmd.optString("text").lowercase()
            return SENSITIVE_WORDS.any { t.contains(it) }
        }
        return false
    }

    fun describe(cmd: JSONObject): String = when (cmd.optString("action")) {
        "send_sms" -> {
            val who = cmd.optString("contact").ifBlank { cmd.optString("number") }
            "إرسال رسالة إلى $who (${cmd.optString("number")}):\n«${cmd.optString("body")}»"
        }
        "click" -> "النقر على «${cmd.optString("text")}»"
        else -> cmd.toString()
    }

    fun execute(ctx: Context, cmd: JSONObject): String {
        val svc = AssistantAccessibilityService.instance
        val needsSvc = cmd.optString("action") !in setOf("open_app", "send_sms")
        if (needsSvc && svc == null) return "خدمة إمكانية الوصول غير مفعّلة"

        return when (cmd.optString("action")) {
            "open_app" -> openApp(ctx, cmd.optString("app_name"))
            "click" -> if (svc!!.clickByText(cmd.optString("text"))) "تم" else "لم أجد العنصر"
            "scroll" -> if (svc!!.scroll(cmd.optString("direction"))) "تم" else "اتجاه غير معروف"
            "type_text" -> if (svc!!.typeText(cmd.optString("text"))) "تم" else "لا يوجد حقل نصي نشط"
            "back" -> { svc!!.back(); "تم" }
            "home" -> { svc!!.home(); "تم" }
            "recents" -> { svc!!.recents(); "تم" }
            "notifications" -> { svc!!.notifications(); "تم" }
            "send_sms" -> sendSms(ctx, svc, cmd.optString("number"), cmd.optString("body"))
            else -> "أمر غير مدعوم"
        }
    }

    private fun openApp(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val n = Ar.norm(name)
        if (n.isEmpty()) return "لم أفهم اسم التطبيق"
        val bare = n.removePrefix("ال")
        val cands = (listOf(n, bare) + (Ar.ALIASES[bare] ?: emptyList())).distinct()
        val labeled = apps.map { Triple(it, Ar.norm(it.loadLabel(pm).toString()), it.activityInfo.packageName.lowercase()) }
        val match = labeled.firstOrNull { (_, l, _) -> l in cands }
            ?: labeled.firstOrNull { (_, l, _) ->
                cands.any { c -> c.length >= 3 && l.length >= 3 && (l.contains(c) || c.contains(l)) }
            }
            ?: labeled.firstOrNull { (_, _, p) ->
                cands.any { c -> c.length >= 4 && c.all { ch -> ch.isLetterOrDigit() && ch.code < 128 } && p.contains(c) }
            }
            ?: return "لم أجد تطبيق «$name»"
        val intent = pm.getLaunchIntentForPackage(match.third) ?: return "تعذّر فتح التطبيق"
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        return "فتحت " + match.first.loadLabel(pm)
    }

    /** Resolves a spoken contact name to a phone number. Returns an error message or null. */
    fun prepare(ctx: Context, cmd: JSONObject): String? {
        if (cmd.optString("action") != "send_sms") return null
        if (cmd.optString("number").isNotBlank()) return null
        val name = cmd.optString("name")
        if (name.isBlank()) return "لم أفهم لمن تريد الإرسال"
        if (ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            return "امنح التطبيق صلاحية جهات الاتصال"
        val hit = findContact(ctx, name) ?: return "لم أجد جهة اتصال باسم «$name»"
        cmd.put("contact", hit.first)
        cmd.put("number", hit.second)
        return null
    }

    private fun findContact(ctx: Context, name: String): Pair<String, String>? {
        val n = Ar.norm(name)
        val cands = listOf(n, n.removePrefix("ل"), n.removePrefix("ال")).filter { it.isNotBlank() }.distinct()
        val c = ctx.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        ) ?: return null
        var exact: Pair<String, String>? = null
        var part: Pair<String, String>? = null
        c.use {
            while (it.moveToNext()) {
                val dn = it.getString(0) ?: continue
                val num = it.getString(1) ?: continue
                val d = Ar.norm(dn)
                if (cands.any { x -> d == x }) { exact = Pair(dn, num); break }
                if (part == null && cands.any { x -> x.length >= 2 && d.contains(x) }) part = Pair(dn, num)
            }
        }
        return exact ?: part
    }

    @Suppress("DEPRECATION")
    private fun sendSms(ctx: Context, svc: AssistantAccessibilityService?, number: String, body: String): String {
        if (number.isBlank() || body.isBlank()) return "الرقم أو نص الرسالة ناقص"

        // Preferred: send directly, no screen taps needed.
        if (ctx.checkSelfPermission(Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            return try {
                val sm = if (Build.VERSION.SDK_INT >= 31) ctx.getSystemService(SmsManager::class.java)
                         else SmsManager.getDefault()
                val parts = sm.divideMessage(body)
                sm.sendMultipartTextMessage(number, null, parts, null, null)
                "أُرسلت الرسالة"
            } catch (e: Exception) {
                "فشل الإرسال: ${e.message}"
            }
        }

        // Fallback: open the compose screen with text filled, then press Send.
        if (svc == null) return "امنح صلاحية الرسائل أو فعّل إمكانية الوصول"
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(number)}"))
            .putExtra("sms_body", body)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        val h = Handler(Looper.getMainLooper())
        var done = false
        for (delay in longArrayOf(1500, 2500, 3500, 4500, 6000)) {
            h.postDelayed({ if (!done && svc.clickSend()) done = true }, delay)
        }
        return "فتحت شاشة الرسالة وأضغط إرسال"
    }
}
