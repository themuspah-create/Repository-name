package com.example.voiceassistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Handler
import android.os.Looper
import org.json.JSONObject

object CommandExecutor {

    private val SENSITIVE_ACTIONS = setOf("send_sms")
    // Clicking a button whose label matches these also needs confirmation.
    private val SENSITIVE_WORDS = listOf(
        "send", "pay", "buy", "delete", "transfer", "confirm", "purchase", "remove",
        "إرسال", "ارسال", "دفع", "شراء", "حذف", "تحويل", "تأكيد", "إزالة"
    )
    private val ALLOWED = setOf(
        "open_app", "click", "scroll", "type_text", "back", "home", "recents", "notifications", "send_sms"
    )

    fun isAllowed(cmd: JSONObject) = cmd.optString("action") in ALLOWED

    /** Decided here in code, never by the model. */
    fun isSensitive(cmd: JSONObject): Boolean {
        val action = cmd.optString("action")
        if (action in SENSITIVE_ACTIONS) return true
        if (action == "click") {
            val t = cmd.optString("text").lowercase()
            return SENSITIVE_WORDS.any { t.contains(it) }
        }
        return false
    }

    fun describe(cmd: JSONObject): String = when (cmd.optString("action")) {
        "send_sms" -> "إرسال رسالة إلى ${cmd.optString("number")}:\n«${cmd.optString("body")}»"
        "click" -> "النقر على «${cmd.optString("text")}»"
        else -> cmd.toString()
    }

    fun execute(ctx: Context, cmd: JSONObject): String {
        val svc = AssistantAccessibilityService.instance
        val needsSvc = cmd.optString("action") != "open_app"
        if (needsSvc && svc == null) return "خدمة إمكانية الوصول غير مفعّلة"

        return when (cmd.optString("action")) {
            "open_app" -> openApp(ctx, cmd.optString("app_name"))
            "click" -> if (svc!!.clickByText(cmd.optString("text"))) "تم" else "لم أجد العنصر"
            "scroll" -> if (svc!!.scroll(cmd.optString("direction"))) "تم" else "اتجاه غير معروف"
            "type_text" -> if (svc!!.typeText(cmd.optString("text"))) "تم" else "لا يوجد حقل نصي نشط"
            "back" -> { svc!!.back(); "تم" }
            "home" -> { svc!!.home(); "تم" }
            "recents" -> { svc!!.recents(); "تم" }
            "notifications" -> { svc!!.notifications(); "تم" }
            "send_sms" -> sendSms(ctx, svc!!, cmd.optString("number"), cmd.optString("body"))
            else -> "أمر غير مدعوم"
        }
    }

    private fun openApp(ctx: Context, name: String): String {
        val pm = ctx.packageManager
        val apps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0
        )
        val n = Ar.norm(name)
        if (n.isEmpty()) return "لم أفهم اسم التطبيق"
        val bare = n.removePrefix("ال")
        val cands = (listOf(n, bare) + (Ar.ALIASES[bare] ?: emptyList())).distinct()
        val labeled = apps.map { Triple(it, Ar.norm(it.loadLabel(pm).toString()), it.activityInfo.packageName.lowercase()) }
        val match = labeled.firstOrNull { (_, l, _) -> l in cands }
            ?: labeled.firstOrNull { (_, l, _) ->
                cands.any { c -> c.length >= 3 && l.length >= 3 && (l.contains(c) || c.contains(l)) }
            }
            ?: labeled.firstOrNull { (_, _, p) ->
                cands.any { c -> c.length >= 4 && c.all { ch -> ch.isLetterOrDigit() && ch.code < 128 } && p.contains(c) }
            }
            ?: return "لم أجد تطبيق «$name»"
        val intent = pm.getLaunchIntentForPackage(match.third) ?: return "تعذّر فتح التطبيق"
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        return "فتحت " + match.first.loadLabel(pm)
    }

    private fun sendSms(ctx: Context, svc: AssistantAccessibilityService, number: String, body: String): String {
        if (number.isBlank() || body.isBlank()) return "الرقم أو نص الرسالة ناقص"
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(number)}"))
            .putExtra("sms_body", body)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        // The user already confirmed; now press the app's Send button.
        val h = Handler(Looper.getMainLooper())
        val labels = listOf("Send", "إرسال")
        for (delay in longArrayOf(1500, 2500)) {
            h.postDelayed({ labels.any { svc.clickByText(it) } }, delay)
        }
        return "جارٍ إرسال الرسالة"
    }
}
