package com.example.voiceassistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Swap this interface's implementation for an on-device model later. */
interface LlmEngine {
    /** Takes the transcribed speech, returns a JSON command string. Runs off the main thread. */
    fun interpret(text: String): String
}

class CloudEngine(private val ctx: Context) : LlmEngine {

    private val system = """
You convert ONE spoken command (Arabic or English) into ONE JSON object. Output JSON only, no prose.
Schema: {"action": "open_app|click|scroll|type_text|back|home|recents|notifications|send_sms|none",
 "app_name": "...", "text": "...", "direction": "up|down|left|right", "number": "digits only", "body": "..."}
- open_app uses app_name (the app's display name).
- click uses text (the visible label of the button).
- scroll uses direction (down = see content further down).
- type_text uses text.
- send_sms uses number and body. Never invent a number; if missing use {"action":"none"}.
- If the request is unclear or unsupported, output {"action":"none"}.
""".trimIndent()

    override fun interpret(text: String): String {
        val base = Prefs.get(ctx, "base_url", "https://api.openai.com/v1").trimEnd('/')
        val key = Prefs.get(ctx, "api_key", "")
        val model = Prefs.get(ctx, "model", "gpt-4o-mini")

        val body = JSONObject()
            .put("model", model)
            .put("temperature", 0)
            .put("response_format", JSONObject().put("type", "json_object"))
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", system))
                .put(JSONObject().put("role", "user").put("content", text)))

        val conn = (URL("$base/chat/completions").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15000
            readTimeout = 30000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            if (key.isNotEmpty()) setRequestProperty("Authorization", "Bearer $key")
        }
        conn.outputStream.use { it.write(body.toString().toByteArray()) }
        val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
        val resp = stream.bufferedReader().use { it.readText() }
        if (conn.responseCode !in 200..299) throw RuntimeException("HTTP ${conn.responseCode}")
        return JSONObject(resp).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }
}

fun parseCommand(raw: String): JSONObject? {
    val s = raw.indexOf('{'); val e = raw.lastIndexOf('}')
    if (s < 0 || e < s) return null
    return try { JSONObject(raw.substring(s, e + 1)) } catch (_: Exception) { null }
}
