package com.example.voiceassistant

import org.json.JSONObject

/** Turns transcribed speech into a JSON command string. Runs fully on the device. */
interface LlmEngine {
    fun interpret(text: String): String
}

fun parseCommand(raw: String): JSONObject? {
    val s = raw.indexOf('{'); val e = raw.lastIndexOf('}')
    if (s < 0 || e < s) return null
    return try { JSONObject(raw.substring(s, e + 1)) } catch (_: Exception) { null }
}

object Ar {
    /** Lowercase, unify Arabic letter variants, drop diacritics, convert Arabic digits. */
    fun norm(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase()) {
            when {
                ch == '\u0623' || ch == '\u0625' || ch == '\u0622' -> sb.append('\u0627')
                ch == '\u0629' -> sb.append('\u0647')
                ch == '\u0649' -> sb.append('\u064A')
                ch in '\u064B'..'\u0652' || ch == '\u0640' -> {}
                ch in '\u0660'..'\u0669' -> sb.append('0' + (ch - '\u0660'))
                ch in '\u06F0'..'\u06F9' -> sb.append('0' + (ch - '\u06F0'))
                else -> sb.append(ch)
            }
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }

    /** Spoken Arabic app name (without "ال") -> names to look for among installed apps. */
    val ALIASES: Map<String, List<String>> = mapOf(
        "واتساب" to listOf("whatsapp"),
        "واتس اب" to listOf("whatsapp"),
        "واتس" to listOf("whatsapp"),
        "يوتيوب" to listOf("youtube"),
        "كروم" to listOf("chrome"),
        "جوجل" to listOf("google"),
        "قوقل" to listOf("google"),
        "كاميره" to listOf("camera"),
        "اعدادات" to listOf("settings"),
        "تيليجرام" to listOf("telegram"),
        "تلغرام" to listOf("telegram"),
        "فيسبوك" to listOf("facebook"),
        "فيس بوك" to listOf("facebook"),
        "انستغرام" to listOf("instagram"),
        "انستقرام" to listOf("instagram"),
        "انستا" to listOf("instagram"),
        "تويتر" to listOf("twitter", "x"),
        "تيك توك" to listOf("tiktok"),
        "رسائل" to listOf("messages", "messaging", "sms"),
        "هاتف" to listOf("phone", "dialer"),
        "اتصال" to listOf("phone", "dialer"),
        "خرائط" to listOf("maps"),
        "جيميل" to listOf("gmail"),
        "بريد" to listOf("gmail", "mail"),
        "سناب شات" to listOf("snapchat"),
        "سناب" to listOf("snapchat"),
        "صور" to listOf("photos", "gallery"),
        "معرض" to listOf("gallery", "photos"),
        "ساعه" to listOf("clock"),
        "منبه" to listOf("clock"),
        "حاسبه" to listOf("calculator"),
        "متجر" to listOf("play store", "store"),
        "بلاي ستور" to listOf("play store"),
        "سبوتيفاي" to listOf("spotify"),
        "نتفليكس" to listOf("netflix"),
        "ملفات" to listOf("files"),
        "جهات الاتصال" to listOf("contacts"),
        "تقويم" to listOf("calendar"),
        "باينانس" to listOf("binance"),
        "بينانس" to listOf("binance")
    )

    /** Edit distance between two strings. */
    fun lev(a: String, b: String): Int {
        if (a == b) return 0
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + cost)
                prev = tmp
            }
        }
        return dp[b.length]
    }

    /** True when two words are the same up to a small speech-recognition slip. */
    fun close(a: String, b: String): Boolean {
        val m = minOf(a.length, b.length)
        val tol = if (m < 4) 0 else if (m < 8) 1 else 2
        return lev(a, b) <= tol
    }

    fun aliasFor(name: String): List<String>? {
        ALIASES[name]?.let { return it }
        return ALIASES.entries.firstOrNull { close(name, it.key) }?.value
    }
}


/** Rule-based Arabic/English command understanding with speech-error tolerance. No model, no network. */
class LocalEngine : LlmEngine {

    private fun cmd(action: String, vararg kv: Pair<String, String>): String {
        val o = JSONObject().put("action", action)
        kv.forEach { o.put(it.first, it.second) }
        return o.toString()
    }

    /** Returns the number of words in the matched prefix, or null. */
    private fun match(t: String, vararg prefixes: String): Int? {
        for (p in prefixes.sortedByDescending { it.length }) {
            if (t == p || t.startsWith("$p ")) return p.split(" ").size
        }
        return null
    }

    private fun tailOf(orig: String, words: Int): String =
        orig.split(Regex("\\s+")).drop(words).joinToString(" ").trim()

    private fun isPhrase(t: String, vararg phrases: String): Boolean =
        phrases.any { Ar.close(t, Ar.norm(it)) }

    // Polite / filler words in Arabic dialects and English that carry no meaning for the command.
    private val fillerPhrases: List<List<String>> = listOf(
        "لو سمحت", "من فضلك", "يا مساعد", "ممكن", "ابغى", "ابغا", "ابي", "عايز", "عاوز",
        "اريد", "بدي", "لازم", "تقدر", "please", "can you", "could you", "would you",
        "i want you to", "i want to", "i want", "hey"
    ).map { Ar.norm(it).split(" ") }

    // Verb families (dialects + common recognition slips) -> canonical verb used below.
    private val verbs: Map<String, List<String>> = mapOf(
        "افتح" to listOf("افتح", "فتح", "تفتح", "افتحي", "شغل", "تشغل", "شغلي", "دخلني", "وديني", "روح",
            "ورني", "وريني", "open", "launch", "start"),
        "اضغط" to listOf("اضغط", "انقر", "دوس", "كبس", "اكبس", "اضغطي", "press", "click", "tap"),
        "اكتب" to listOf("اكتب", "كتب", "اكتبي", "type", "write"),
        "ارسل" to listOf("ارسل", "ابعث", "ارسلي", "ابعثلي", "ابعت", "send", "text")
    )

    private fun canonVerb(tok: String): String? {
        for ((canon, variants) in verbs) if (variants.any { Ar.norm(it) == tok }) return canon
        if (tok.length >= 4) {
            for ((canon, variants) in verbs) {
                if (variants.any { v -> val nv = Ar.norm(v); nv.length >= 4 && Ar.close(tok, nv) }) return canon
            }
        }
        return null
    }

    /** Returns (original-case words, normalized words) with fillers removed and the verb unified. */
    private fun preprocess(text: String): Pair<String, String> {
        val o = text.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.toMutableList()
        val n = o.map { Ar.norm(it) }.toMutableList()
        var changed = true
        while (changed) {
            changed = false
            for (ph in fillerPhrases) {
                var i = 0
                while (i + ph.size <= n.size) {
                    if (n.subList(i, i + ph.size) == ph) {
                        repeat(ph.size) { n.removeAt(i); o.removeAt(i) }
                        changed = true
                    } else i++
                }
            }
        }
        if (n.isNotEmpty()) {
            val canon = canonVerb(n[0])
            if (canon != null) {
                n[0] = canon; o[0] = canon
                if (n.size > 1 && n[1] == "لي") { n.removeAt(1); o.removeAt(1) }
                if (canon == "افتح" && n.size > 1 && (n[1] == "الي" || n[1] == "ل")) { n.removeAt(1); o.removeAt(1) }
            }
        }
        return Pair(o.joinToString(" "), n.joinToString(" "))
    }

    override fun interpret(text: String): String {
        val (orig, t) = preprocess(text)
        if (t.isEmpty()) return cmd("none")

        // "أرسل رسالة إلى مؤيد تقول مرحبا"  /  "أرسل رسالة إلى 0501234567 تقول مرحبا"
        if (match(t, "ارسل") != null) {
            val body = Regex(
                "(تقول|نصها|نصه|مضمونها|يقول|saying|says)\\s+(.+)",
                setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
            ).find(orig)?.groupValues?.get(2)?.trim()
            if (body.isNullOrBlank()) return cmd("none")
            val num = Regex("\\d[\\d ]{5,}\\d").find(t)?.value?.replace(" ", "")
            if (num != null) return cmd("send_sms", "number" to num, "body" to body)
            val name = Regex(
                "^ارسل\\s+(?:رساله|message|sms)?\\s*(?:الي|الى|to)?\\s*(.+?)\\s+(?:تقول|نصها|نصه|مضمونها|يقول|saying|says)(?:\\s|$)"
            ).find(t)?.groupValues?.get(1)?.trim()
                ?.removeSuffix(" رساله")?.removeSuffix(" message")?.trim()
            return if (!name.isNullOrBlank()) cmd("send_sms", "name" to name, "body" to body) else cmd("none")
        }

        match(t, "اضغط على", "اضغط")?.let { n ->
            val x = tailOf(orig, n)
            return if (x.isNotEmpty()) cmd("click", "text" to x) else cmd("none")
        }

        match(t, "اكتب")?.let { n ->
            val x = tailOf(orig, n)
            return if (x.isNotEmpty()) cmd("type_text", "text" to x) else cmd("none")
        }

        if (isPhrase(t, "رجوع", "ارجع", "للخلف", "الي الخلف", "خلف", "back", "go back", "ارجعني")) return cmd("back")
        if (t.contains("الرئيسيه") || isPhrase(t, "home", "go home", "home screen", "الهوم", "البيت", "الصفحه الرئيسيه"))
            return cmd("home")
        if (t.contains("الاخيره") || t.contains("recent") || isPhrase(t, "التطبيقات الاخيره", "recent apps"))
            return cmd("recents")
        if (t.contains("الاشعار") || t.contains("notification")) return cmd("notifications")

        if (t.contains("للاسفل") || t.contains("scroll down") || isPhrase(t, "down", "انزل", "نزل", "تحت", "اسفل") ||
            t.startsWith("انزل ") || t.startsWith("نزل ")
        ) return cmd("scroll", "direction" to "down")
        if (t.contains("للاعلي") || t.contains("للاعلى") || t.contains("scroll up") ||
            isPhrase(t, "up", "اطلع", "اصعد", "فوق", "اعلي") || t.startsWith("اطلع ")
        ) return cmd("scroll", "direction" to "up")

        match(t, "افتح")?.let { n ->
            val name = Ar.norm(tailOf(orig, n))
                .removePrefix("تطبيق ").removePrefix("برنامج ").removePrefix("app ").trim()
            return if (name.isNotEmpty()) cmd("open_app", "app_name" to name) else cmd("none")
        }

        return cmd("none")
    }
}
