package com.example.voiceassistant

import org.json.JSONObject

/** Turns transcribed speech into a JSON command string. Runs fully on the device. */
interface LlmEngine {
    fun interpret(text: String): String
}

fun parseCommand(raw: String): JSONObject? {
    val s = raw.indexOf('{'); val e = raw.lastIndexOf('}')
    if (s < 0 || e < s) return null
    return try { JSONObject(raw.substring(s, e + 1)) } catch (_: Exception) { null }
}

object Ar {
    /** Lowercase, unify Arabic letter variants, drop diacritics, convert Arabic digits. */
    fun norm(s: String): String {
        val sb = StringBuilder()
        for (ch in s.lowercase()) {
            when {
                ch == '\u0623' || ch == '\u0625' || ch == '\u0622' -> sb.append('\u0627')
                ch == '\u0629' -> sb.append('\u0647')
                ch == '\u0649' -> sb.append('\u064A')
                ch in '\u064B'..'\u0652' || ch == '\u0640' -> {}
                ch in '\u0660'..'\u0669' -> sb.append('0' + (ch - '\u0660'))
                ch in '\u06F0'..'\u06F9' -> sb.append('0' + (ch - '\u06F0'))
                else -> sb.append(ch)
            }
        }
        return sb.toString().replace(Regex("\\s+"), " ").trim()
    }

    /** Spoken Arabic app name (without "ال") -> names to look for among installed apps. */
    val ALIASES: Map<String, List<String>> = mapOf(
        "واتساب" to listOf("whatsapp"),
        "واتس اب" to listOf("whatsapp"),
        "واتس" to listOf("whatsapp"),
        "يوتيوب" to listOf("youtube"),
        "كروم" to listOf("chrome"),
        "جوجل" to listOf("google"),
        "قوقل" to listOf("google"),
        "كاميره" to listOf("camera"),
        "اعدادات" to listOf("settings"),
        "تيليجرام" to listOf("telegram"),
        "تلغرام" to listOf("telegram"),
        "فيسبوك" to listOf("facebook"),
        "فيس بوك" to listOf("facebook"),
        "انستغرام" to listOf("instagram"),
        "انستقرام" to listOf("instagram"),
        "انستا" to listOf("instagram"),
        "تويتر" to listOf("twitter", "x"),
        "تيك توك" to listOf("tiktok"),
        "رسائل" to listOf("messages", "messaging", "sms"),
        "هاتف" to listOf("phone", "dialer"),
        "اتصال" to listOf("phone", "dialer"),
        "خرائط" to listOf("maps"),
        "جيميل" to listOf("gmail"),
        "بريد" to listOf("gmail", "mail"),
        "سناب شات" to listOf("snapchat"),
        "سناب" to listOf("snapchat"),
        "صور" to listOf("photos", "gallery"),
        "معرض" to listOf("gallery", "photos"),
        "ساعه" to listOf("clock"),
        "منبه" to listOf("clock"),
        "حاسبه" to listOf("calculator"),
        "متجر" to listOf("play store", "store"),
        "بلاي ستور" to listOf("play store"),
        "سبوتيفاي" to listOf("spotify"),
        "نتفليكس" to listOf("netflix"),
        "ملفات" to listOf("files"),
        "جهات الاتصال" to listOf("contacts"),
        "تقويم" to listOf("calendar"),
        "باينانس" to listOf("binance"),
        "بينانس" to listOf("binance")
    )
}

/** Rule-based Arabic/English command understanding. No model, no network, instant. */
class LocalEngine : LlmEngine {

    private fun cmd(action: String, vararg kv: Pair<String, String>): String {
        val o = JSONObject().put("action", action)
        kv.forEach { o.put(it.first, it.second) }
        return o.toString()
    }

    /** Returns the number of words in the matched prefix, or null. */
    private fun match(t: String, vararg prefixes: String): Int? {
        for (p in prefixes.sortedByDescending { it.length }) {
            if (t == p || t.startsWith("$p ")) return p.split(" ").size
        }
        return null
    }

    private fun tailOf(orig: String, words: Int): String =
        orig.split(Regex("\\s+")).drop(words).joinToString(" ").trim()

    override fun interpret(text: String): String {
        val orig = text.trim()
        val t = Ar.norm(orig)

        // "أرسل رسالة إلى مؤيد تقول مرحبا"  /  "أرسل رسالة إلى 0501234567 تقول مرحبا"
        if (match(t, "ارسل", "ابعث", "send", "text") != null) {
            val body = Regex(
                "(تقول|نصها|نصه|مضمونها|يقول|saying|says)\\s+(.+)",
                setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL)
            ).find(orig)?.groupValues?.get(2)?.trim()
            if (body.isNullOrBlank()) return cmd("none")
            val num = Regex("\\d[\\d ]{5,}\\d").find(t)?.value?.replace(" ", "")
            if (num != null) return cmd("send_sms", "number" to num, "body" to body)
            val name = Regex(
                "^(?:ارسل|ابعث|send|text)\\s+(?:رساله|message|sms)?\\s*(?:الى|الي|to)?\\s*(.+?)\\s+(?:تقول|نصها|نصه|مضمونها|يقول|saying|says)(?:\\s|$)"
            ).find(t)?.groupValues?.get(1)?.trim()
                ?.removeSuffix(" رساله")?.removeSuffix(" message")?.trim()
            return if (!name.isNullOrBlank()) cmd("send_sms", "name" to name, "body" to body) else cmd("none")
        }

        match(t, "اضغط على", "اضغط", "انقر على", "انقر", "click on", "click", "tap on", "tap", "press")?.let { n ->
            val x = tailOf(orig, n)
            return if (x.isNotEmpty()) cmd("click", "text" to x) else cmd("none")
        }

        match(t, "اكتب", "type", "write")?.let { n ->
            val x = tailOf(orig, n)
            return if (x.isNotEmpty()) cmd("type_text", "text" to x) else cmd("none")
        }

        if (t in setOf("رجوع", "ارجع", "للخلف", "الى الخلف", "back", "go back")) return cmd("back")
        if (t.contains("الرئيسيه") || t in setOf("home", "go home", "home screen")) return cmd("home")
        if (t.contains("الاخيره") || t.contains("recent")) return cmd("recents")
        if (t.contains("الاشعارات") || t.contains("notification")) return cmd("notifications")

        if (t.contains("للاسفل") || t.contains("scroll down") || t == "down" ||
            t == "انزل" || t.startsWith("انزل ") || t == "نزل"
        ) return cmd("scroll", "direction" to "down")
        if (t.contains("للاعلى") || t.contains("scroll up") || t == "up" ||
            t == "اطلع" || t.startsWith("اطلع ") || t == "اصعد"
        ) return cmd("scroll", "direction" to "up")

        match(t, "افتح", "شغل", "روح الى", "open", "launch", "start")?.let { n ->
            val name = Ar.norm(tailOf(orig, n))
                .removePrefix("تطبيق ").removePrefix("برنامج ").removePrefix("app ").trim()
            return if (name.isNotEmpty()) cmd("open_app", "app_name" to name) else cmd("none")
        }

        return cmd("none")
    }
}
