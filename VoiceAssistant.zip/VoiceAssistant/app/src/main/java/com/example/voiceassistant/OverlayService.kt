package com.example.voiceassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import java.util.concurrent.Executors
import kotlin.math.abs

class OverlayService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.voiceassistant.STOP"
        private const val CHANNEL = "assistant"
        private const val NOTIF_ID = 1
        private const val IDLE = 0xFF607D8B.toInt()
        private const val LISTENING = 0xFF2E7D32.toInt()
        private const val BUSY = 0xFFEF6C00.toInt()
    }

    private lateinit var wm: WindowManager
    private var bubble: ImageView? = null
    private var recognizer: SpeechRecognizer? = null
    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var listening = false
    private var busy = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (bubble != null) return START_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        startAsForeground()
        addBubble()
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "المساعد الصوتي", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("المساعد الصوتي يعمل")
            .setContentText("اضغط «إيقاف» لإنهاء الخدمة")
            .addAction(0, "إيقاف", stop)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    // ---------- floating bubble ----------
    private fun addBubble() {
        val d = resources.displayMetrics.density
        val size = (56 * d).toInt()
        val pad = (12 * d).toInt()
        val v = ImageView(this).apply {
            setImageResource(android.R.drawable.ic_btn_speak_now)
            setColorFilter(Color.WHITE)
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(IDLE) }
        }
        val lp = WindowManager.LayoutParams(
            size, size, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 300 }

        v.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var t0 = 0L; var moved = false
            override fun onTouch(view: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> {
                        sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY
                        t0 = SystemClock.uptimeMillis(); moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - tx; val dy = e.rawY - ty
                        if (abs(dx) > 15 || abs(dy) > 15) moved = true
                        if (moved) { lp.x = sx + dx.toInt(); lp.y = sy + dy.toInt(); wm.updateViewLayout(v, lp) }
                    }
                    MotionEvent.ACTION_UP -> if (!moved) {
                        if (SystemClock.uptimeMillis() - t0 > 700) stopSelf() else toggleListening()
                    }
                }
                return true
            }
        })
        wm.addView(v, lp)
        bubble = v
    }

    private fun setColor(c: Int) { (bubble?.background as? GradientDrawable)?.setColor(c) }

    // ---------- continuous speech recognition ----------
    private fun toggleListening() {
        if (listening) {
            listening = false
            recognizer?.cancel()
            setColor(IDLE)
        } else {
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                toast("التعرف على الصوت غير متاح على هذا الجهاز"); return
            }
            listening = true
            setColor(LISTENING)
            startRecognizer()
        }
    }

    private fun startRecognizer() {
        if (!listening || busy) return
        if (recognizer == null) {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply { setRecognitionListener(listener) }
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Prefs.get(this@OverlayService, "lang", "ar-SA"))
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        recognizer?.startListening(i)
    }

    private fun restart(delayMs: Long) {
        main.postDelayed({ startRecognizer() }, delayMs)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: android.os.Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: android.os.Bundle?) {}
        override fun onEvent(eventType: Int, params: android.os.Bundle?) {}

        override fun onError(error: Int) {
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    toast("امنح التطبيق صلاحية الميكروفون"); listening = false; setColor(IDLE)
                }
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_CLIENT -> {
                    recognizer?.destroy(); recognizer = null; restart(1000)
                }
                SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> restart(300)
                12, 13 -> {
                    toast("لغة الكلام غير متاحة. حمّل حزمة اللغة العربية للتعرف دون اتصال ثم جرّب")
                    listening = false; setColor(IDLE)
                }
                else -> { toast("خطأ في التعرف على الصوت (رمز $error)"); restart(3000) }
            }
        }

        override fun onResults(results: android.os.Bundle?) {
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
            if (text.isNullOrBlank()) { restart(300); return }
            handleSpeech(text)
        }
    }

    // ---------- speech -> LLM -> action ----------
    private fun handleSpeech(text: String) {
        busy = true
        setColor(BUSY)
        toast("🎤 $text")
        worker.execute {
            val cmd = try { parseCommand(LocalEngine().interpret(text)) } catch (e: Exception) {
                main.post { toast("خطأ في النموذج: ${e.message}") }; null
            }
            main.post { onCommand(cmd) }
        }
    }

    private fun onCommand(cmd: org.json.JSONObject?) {
        if (cmd == null || !CommandExecutor.isAllowed(cmd)) {
            if (cmd != null) toast("لم أفهم الأمر")
            finishCommand(); return
        }
        if (CommandExecutor.isSensitive(cmd)) {
            confirm(CommandExecutor.describe(cmd)) { ok ->
                if (ok) toast(CommandExecutor.execute(this, cmd)) else toast("أُلغي الأمر")
                finishCommand()
            }
        } else {
            toast(CommandExecutor.execute(this, cmd))
            finishCommand()
        }
    }

    private fun finishCommand() {
        busy = false
        setColor(if (listening) LISTENING else IDLE)
        restart(800)
    }

    // ---------- confirmation dialog (explicit user tap) ----------
    private fun confirm(message: String, callback: (Boolean) -> Unit) {
        val d = resources.displayMetrics.density
        val p = (16 * d).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xF0212121.toInt())
            setPadding(p, p, p, p)
        }
        box.addView(TextView(this).apply {
            text = "تأكيد الإجراء:\n$message"; setTextColor(Color.WHITE); textSize = 16f
        })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        var done = false
        fun finish(ok: Boolean) {
            if (done) return
            done = true
            try { wm.removeView(box) } catch (_: Exception) {}
            callback(ok)
        }
        row.addView(Button(this).apply { text = "تأكيد"; setOnClickListener { finish(true) } })
        row.addView(Button(this).apply { text = "إلغاء"; setOnClickListener { finish(false) } })
        box.addView(row)
        val lp = WindowManager.LayoutParams(
            (320 * d).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }
        wm.addView(box, lp)
        main.postDelayed({ finish(false) }, 15000) // auto-cancel
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        listening = false
        main.removeCallbacksAndMessages(null)
        recognizer?.destroy(); recognizer = null
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        worker.shutdownNow()
        super.onDestroy()
    }
}
